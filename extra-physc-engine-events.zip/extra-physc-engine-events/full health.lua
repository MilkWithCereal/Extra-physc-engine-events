-- Event notes hooks
function onEvent(name)
	if name == 'full health' then
	setProperty('health',100);
		end
		end