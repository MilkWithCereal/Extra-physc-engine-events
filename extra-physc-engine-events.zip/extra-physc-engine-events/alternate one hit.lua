-- Event notes hooks
function onEvent(name)
	if name == 'alternate one hit' then
	cameraShake(gamecam, 0.02, 0.1)
	setProperty('health',0.01);
		end
		end