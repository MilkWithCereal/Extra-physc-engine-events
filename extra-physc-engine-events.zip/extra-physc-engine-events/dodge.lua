function onEvent(name)
	if name == 'dodge' then
	if keyPressed('down') then
	
	else
	setProperty('health', -500);
	playSound(hit,1)
		end
		end
		end